# Prompts Utilizados en el Proyecto

## 📘 Resumen de documentos
"Resume el siguiente documento técnico en no más de 10 líneas destacando los puntos clave:"

## 📋 Visualización tipo checklist
"Lee el siguiente contrato y genera una imagen tipo checklist en la que se marquen en verde los requisitos cumplidos y en rojo los que faltan. Requisitos: [incluir lista]"

## 🧠 Mapa mental de documento técnico
"A partir del siguiente documento técnico, crea un mapa mental visual con conceptos clave, categorías y conexiones lógicas entre ellos."
