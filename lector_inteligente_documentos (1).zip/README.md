# 📚 Lector Inteligente de Documentos con Generación de Resúmenes y Visualizaciones

## 💡 Introducción

### Nombre del Proyecto
**Lector inteligente de documentos con generación de resúmenes y visualizaciones**

### Presentación del Problema
En contextos de control de negocios, como en la gestión de contratos con proveedores o documentación técnica de sistemas de control, se trabaja con documentos extensos, complejos y altamente técnicos. Esto demanda tiempo, precisión y conocimientos específicos.
La lectura manual puede ocasionar errores, omisiones y lentitud. Además, comprender relaciones entre conceptos clave puede resultar difícil sin ayuda visual.

## 🧠 Desarrollo de la Solución
Este proyecto propone una solución basada en Inteligencia Artificial mediante el uso de prompts diseñados para tareas específicas:
- ✅ Resúmenes automáticos de documentos largos.
- 🧩 Mapas mentales que representen relaciones conceptuales del texto.
- 📋 Visualizaciones tipo checklist para validar requisitos contractuales.

Se utilizan modelos avanzados:
- ChatGPT (para tareas de texto)
- DALL·E (para tareas de generación de imágenes)

## 📌 Ejemplos de Prompts Utilizados
- **Resumen**:
  > "Resume el siguiente documento en no más de 10 líneas destacando los puntos técnicos clave."
- **Visualización de cumplimiento en contratos**:
  > "Genera una imagen checklist con ítems marcados en verde si están presentes y en rojo si faltan según esta lista: [lista de requisitos]."
- **Mapa mental técnico**:
  > "A partir del siguiente documento técnico, crea un mapa mental visual que refleje los conceptos clave y su relación."

## ✔️ Justificación de la Viabilidad
- Factibilidad técnica: los modelos están disponibles y accesibles vía API.
- Documentación real disponible: contratos y manuales técnicos reales se usarán como entrada.
- Viabilidad temporal: se planificó en etapas alcanzables dentro del cronograma del curso.
- Limitaciones previstas: documentos confidenciales serán excluidos. Se mejorará la comprensión de textos técnicos mediante prompts especializados.

## 🎯 Objetivos del Proyecto
1. Automatizar la lectura y análisis de documentos.
2. Mejorar la comprensión de contratos y documentos técnicos mediante resúmenes e imágenes.
3. Minimizar el número de consultas a la API, optimizando costos.

## 🛠️ Metodología
1. Recolección de documentos reales.
2. Diseño iterativo de prompts según necesidad.
3. Implementación y pruebas en Jupyter Notebook.
4. Visualización de resultados y análisis de eficacia.
5. Optimización de código y prompts para minimizar consultas.

## 🧰 Herramientas y Tecnologías

| Herramienta       | Uso principal                               |
|-------------------|---------------------------------------------|
| ChatGPT (GPT-4.5) | Generación de resúmenes y análisis textual  |
| DALL·E 3          | Generación de visualizaciones e imágenes    |
| Jupyter Notebook  | Desarrollo, pruebas y demostración técnica  |
| GitHub            | Control de versiones y documentación        |
| Python            | Lenguaje principal del proyecto             |

## 💻 Implementación Básica (fragmento de código)
```python
import openai

def generar_resumen(texto):
    prompt = f"Resume el siguiente documento técnico en 10 líneas:\n{texto}"
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return response['choices'][0]['message']['content']
```

## 📊 Resultados Esperados
- Reducción significativa del tiempo de lectura.
- Visualizaciones claras para comprender rápidamente los documentos.
- Menor cantidad de errores humanos en análisis de contratos.

## 📎 Costos y Optimización
Se prioriza el uso de prompts concisos, agrupando tareas en una sola consulta cuando sea posible. Esto reduce el número de llamadas a la API, optimizando el presupuesto sin sacrificar precisión.

## 📁 Estructura del Repositorio
```
📁 notebooks/                → Jupyter con demostración funcional
📁 prompts/                  → Prompt engineering documentado
📁 resultados/               → Imágenes y resúmenes generados
📄 requirements.txt          → Dependencias de Python necesarias
```

## 🙌 Autor
**Ricardo Eber Pastrana**  
Comisión 84185 – Curso de Inteligencia Artificial | Coderhouse
